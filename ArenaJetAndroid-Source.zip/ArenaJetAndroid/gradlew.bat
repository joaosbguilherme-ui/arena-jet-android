@echo off
setlocal
set APP_HOME=%~dp0
set WRAPPER=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%WRAPPER%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://raw.githubusercontent.com/gradle/gradle/v8.9.0/gradle/wrapper/gradle-wrapper.jar'; Invoke-WebRequest -UseBasicParsing $u -OutFile '%WRAPPER%'"
  if errorlevel 1 exit /b 1
)
java %JAVA_OPTS% %GRADLE_OPTS% -classpath "%WRAPPER%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
