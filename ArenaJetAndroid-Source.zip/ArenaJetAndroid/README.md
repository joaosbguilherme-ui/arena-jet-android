# Arena Jet para Android — projeto Android Studio

Este projeto empacota o jogo original `arena-jet.html` em uma Activity Android de tela cheia e substitui o multiplayer Firebase por Bluetooth clássico (RFCOMM). O modo contra bots permanece local. O projeto contém o **código-fonte**, não um APK compilado: este ambiente não dispõe do Android SDK/Gradle para gerar e testar um APK aqui.

## O que está preparado

- Jogo HTML/Canvas incorporado no app (não abre o navegador).
- Controles por toque e orientação horizontal.
- Partida local sem internet: um celular hospeda a sala e simula o jogo; os demais enviam comandos e recebem o estado da partida.
- Lobby com nomes, equipes, modos e bots.
- Mensagens de jogo encaminhadas por uma ponte JavaScript/Java e sockets Bluetooth clássicos.
- Solicitação de permissões Bluetooth em tempo de execução nos Androids recentes.

## Requisitos para compilar

- Android Studio atualizado, com Android SDK Platform 35 instalado.
- JDK 17 (o JDK embutido no Android Studio é adequado).
- Conexão à internet na primeira sincronização para baixar Gradle/Android Gradle Plugin.

Abra a pasta `ArenaJetAndroid` no Android Studio. Aguarde a sincronização Gradle e use **Build > Build APK(s)**. O APK de depuração normalmente será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Também é possível compilar pelo terminal, dentro da pasta do projeto, após o Android Studio configurar o SDK:

```bash
./gradlew assembleDebug
```

Como o arquivo binário do wrapper não está empacotado, o script `gradlew` deste projeto baixa o bootstrap do Gradle da origem oficial no primeiro uso se ele ainda não estiver incluído; é necessário ter internet nessa primeira execução. Para compilar no Windows, use `gradlew.bat assembleDebug`. Android Gradle Plugin 8.7.3 usa Gradle 8.9 e JDK 17.


## Compilar na nuvem pelo celular (GitHub Actions)

O projeto inclui `.github/workflows/build-apk.yml`. Depois de colocar os arquivos deste projeto em um repositório GitHub, abra a aba **Actions**, selecione **Compilar APK Arena Jet** e toque em **Run workflow**. Quando a execução terminar com sucesso, abra a execução, desça até **Artifacts** e baixe `Arena-Jet-APK-debug`. Extraia o ZIP do artefato para encontrar `app-debug.apk`. O workflow compila o APK de depuração; ele não substitui testes em aparelhos reais.

## Como jogar via Bluetooth

1. Instale o mesmo APK nos celulares. Ative o Bluetooth.
2. Nas configurações Bluetooth do Android, pareie cada celular com o celular que será anfitrião. Aceite as solicitações de pareamento nos dois aparelhos.
3. No anfitrião, abra Arena Jet, escolha **Criar sala Bluetooth**, configure a partida e toque em **Criar sala Bluetooth**. Autorize **Dispositivos próximos** e permita que o Android torne o celular detectável, caso solicitado.
4. Nos outros celulares, abra Arena Jet, escolha **Entrar via Bluetooth**, atualize a lista e toque no anfitrião pareado.
5. Quando os jogadores aparecerem no lobby, o anfitrião toca em **Iniciar partida**. Mantenha o jogo aberto no anfitrião durante a partida.

A lista do app mostra dispositivos **já pareados**; ela não é uma busca por aparelhos não pareados. Se não encontrar o anfitrião, faça o pareamento primeiro pelas configurações do Android. A opção de tornar detectável pode variar um pouco por fabricante/versão Android.

## Limitações e validação

- A comunicação foi implementada para partidas locais com até 8 participantes incluindo o anfitrião; o desempenho real depende dos celulares e da qualidade do rádio Bluetooth.
- O anfitrião é autoritativo: se ele fechar o app ou perder a conexão, a partida termina para os clientes.
- O multiplayer Bluetooth e a compilação precisam ser testados em dois ou mais aparelhos físicos. Como este ambiente não tem Android SDK, não afirmo que o APK foi compilado nem que a partida já passou por teste real em celulares.
- O jogo original usa uma quantidade considerável de dados de estado em cada sincronização; se houver instabilidade em celulares específicos, a próxima otimização indicada é reduzir a frequência/tamanho dos snapshots.

## Estrutura

- `app/src/main/java/com/arenajet/game/MainActivity.java` — WebView, permissões e transporte Bluetooth RFCOMM.
- `app/src/main/assets/arena-jet.html` — jogo e protocolo de lobby/partida Bluetooth.
- `app/src/main/AndroidManifest.xml` — permissões e Activity de tela cheia.
- `reference/arena-jet-original.html` — cópia original recebida, sem as adaptações Bluetooth.
