package com.arenajet.game;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {
    private static final String TAG = "ArenaJet";
    private static final UUID SERVICE_UUID = UUID.fromString("7d2ea28a-f7bd-485a-bd9d-92ad6ecfe93e");
    private static final int REQUEST_PERMISSIONS = 301;
    private static final int REQUEST_ENABLE_BT = 302;
    private static final int REQUEST_DISCOVERABLE = 303;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Map<String, BtConnection> connections = new ConcurrentHashMap<>();
    private WebView webView;
    private BluetoothAdapter adapter;
    private volatile BluetoothServerSocket serverSocket;
    private volatile boolean isHost = false;
    private volatile boolean shuttingDown = false;
    private String pendingAction = "";
    private String pendingAddress = "";
    private String pendingName = "Soldado";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        adapter = BluetoothAdapter.getDefaultAdapter();
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B1220);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidBTBridge(), "AndroidBT");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "JS " + consoleMessage.message() + " @" + consoleMessage.lineNumber());
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/arena-jet.html");
    }

    private final class AndroidBTBridge {
        @JavascriptInterface public void startHost() {
            mainHandler.post(() -> beginAction("host", "", ""));
        }
        @JavascriptInterface public void listPairedDevices() {
            mainHandler.post(() -> beginAction("list", "", ""));
        }
        @JavascriptInterface public void connect(String address, String playerName) {
            mainHandler.post(() -> beginAction("connect", address, playerName));
        }
        @JavascriptInterface public void sendTo(String peer, String payload) {
            if (payload == null) return;
            if (isHost) {
                BtConnection c = connections.get(peer);
                if (c != null) c.send(payload);
            } else {
                BtConnection c = connections.get("host");
                if (c != null) c.send(payload);
            }
        }
        @JavascriptInterface public void broadcast(String payload) {
            if (!isHost || payload == null) return;
            for (BtConnection c : connections.values()) c.send(payload);
        }
        @JavascriptInterface public void disconnect() {
            mainHandler.post(MainActivity.this::disconnectAll);
        }
    }

    private void beginAction(String action, String address, String name) {
        pendingAction = action;
        pendingAddress = address == null ? "" : address.trim();
        pendingName = name == null || name.trim().isEmpty() ? "Soldado" : name.trim();
        if (adapter == null) {
            status("error", "Este aparelho não oferece suporte a Bluetooth.");
            return;
        }
        if (!hasRequiredPermissions()) {
            requestRequiredPermissions();
            return;
        }
        if (!adapter.isEnabled()) {
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);
            } catch (SecurityException e) {
                status("error", "Permissão de Bluetooth negada. Ative-a nas configurações do Android.");
            }
            return;
        }
        continuePendingAction();
    }

    private boolean hasRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE,
                    Manifest.permission.BLUETOOTH_SCAN
            }, REQUEST_PERMISSIONS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean ok = grantResults.length > 0;
            for (int result : grantResults) ok &= result == PackageManager.PERMISSION_GRANTED;
            if (ok) {
                beginActionAfterPermissions();
            } else {
                status("error", "Permissão de dispositivos próximos foi negada. Autorize o Bluetooth para usar partidas locais.");
            }
        }
    }

    private void beginActionAfterPermissions() {
        if (adapter == null) {
            status("error", "Bluetooth indisponível neste aparelho.");
            return;
        }
        if (!adapter.isEnabled()) {
            try {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);
            } catch (SecurityException e) {
                status("error", "Não foi possível ativar o Bluetooth.");
            }
        } else continuePendingAction();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK && adapter != null && adapter.isEnabled()) continuePendingAction();
            else status("error", "Ative o Bluetooth para continuar.");
        }
    }

    private void continuePendingAction() {
        switch (pendingAction) {
            case "host": startHostNow(); break;
            case "list": listPairedNow(); break;
            case "connect": connectNow(pendingAddress, pendingName); break;
            default: status("error", "Ação Bluetooth desconhecida.");
        }
    }

    private void startHostNow() {
        disconnectAll();
        shuttingDown = false;
        isHost = true;
        try {
            Intent discoverable = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverable.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivityForResult(discoverable, REQUEST_DISCOVERABLE);
        } catch (Exception e) {
            Log.w(TAG, "Não foi possível abrir a solicitação de visibilidade Bluetooth", e);
        }
        new Thread(() -> {
            try {
                BluetoothServerSocket server = adapter.listenUsingRfcommWithServiceRecord("Arena Jet", SERVICE_UUID);
                serverSocket = server;
                status("hostReady", "Bluetooth pronto. Pareie este celular com os amigos nas configurações do Android.");
                while (isHost && !shuttingDown) {
                    BluetoothSocket socket = server.accept();
                    if (socket == null) continue;
                    String peer = socket.getRemoteDevice().getAddress();
                    BtConnection connection = new BtConnection(peer, socket);
                    BtConnection old = connections.put(peer, connection);
                    if (old != null) old.closeQuietly();
                    connection.startReader();
                    status("clientConnected", "Um dispositivo se conectou.");
                }
            } catch (IOException | SecurityException e) {
                if (!shuttingDown) {
                    Log.e(TAG, "Bluetooth host failed", e);
                    status("error", "Não foi possível abrir a sala Bluetooth: " + safeMessage(e));
                }
            } finally {
                closeServerSocket();
            }
        }, "ArenaJet-Bluetooth-Server").start();
    }

    private void listPairedNow() {
        try {
            Set<BluetoothDevice> paired = adapter.getBondedDevices();
            List<JSONObject> sorted = new ArrayList<>();
            for (BluetoothDevice device : paired) {
                JSONObject item = new JSONObject();
                item.put("name", device.getName() == null ? "Dispositivo Bluetooth" : device.getName());
                item.put("address", device.getAddress());
                sorted.add(item);
            }
            Collections.sort(sorted, Comparator.comparing(o -> o.optString("name").toLowerCase()));
            JSONArray array = new JSONArray();
            for (JSONObject item : sorted) array.put(item);
            status("pairedDevices", array.toString());
        } catch (SecurityException e) {
            status("error", "O Android não permitiu ler os dispositivos pareados. Verifique a permissão Dispositivos próximos.");
        } catch (Exception e) {
            status("error", "Erro ao listar dispositivos pareados: " + safeMessage(e));
        }
    }

    private void connectNow(String address, String playerName) {
        if (address == null || address.isEmpty()) {
            status("error", "Endereço do dispositivo vazio.");
            return;
        }
        disconnectAll();
        shuttingDown = false;
        isHost = false;
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothDevice device = adapter.getRemoteDevice(address);
                adapter.cancelDiscovery();
                socket = device.createRfcommSocketToServiceRecord(SERVICE_UUID);
                socket.connect();
                BtConnection connection = new BtConnection("host", socket);
                connections.put("host", connection);
                connection.startReader();
                status("connected", "Conectado a " + (device.getName() == null ? address : device.getName()));
                JSONObject hello = new JSONObject();
                hello.put("type", "hello");
                hello.put("name", playerName);
                connection.send(hello.toString());
            } catch (Exception e) {
                if (socket != null) try { socket.close(); } catch (IOException ignored) { }
                Log.e(TAG, "Bluetooth connect failed", e);
                status("error", "Falha ao conectar. Confirme que o outro celular criou a sala e está pareado. " + safeMessage(e));
            }
        }, "ArenaJet-Bluetooth-Connect").start();
    }

    private final class BtConnection {
        final String peer;
        final BluetoothSocket socket;
        final Object writeLock = new Object();
        volatile boolean closed = false;
        BtConnection(String peer, BluetoothSocket socket) { this.peer = peer; this.socket = socket; }

        void startReader() {
            new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while (!closed && (line = reader.readLine()) != null) {
                        if (!line.isEmpty()) dispatchIncoming(peer, line);
                    }
                } catch (IOException | SecurityException e) {
                    if (!shuttingDown) Log.d(TAG, "Bluetooth peer reader ended: " + peer + " / " + safeMessage(e));
                } finally {
                    boolean wasActive = !shuttingDown;
                    connections.remove(peer, this);
                    closeQuietly();
                    if (wasActive) connectionClosed(peer);
                }
            }, "ArenaJet-Bluetooth-Reader-" + peer.replace(':', '_')).start();
        }

        void send(String payload) {
            if (closed || payload == null) return;
            try {
                byte[] bytes = (payload.replace("\r", "").replace("\n", "") + "\n").getBytes(StandardCharsets.UTF_8);
                synchronized (writeLock) {
                    OutputStream out = socket.getOutputStream();
                    out.write(bytes);
                    out.flush();
                }
            } catch (IOException | SecurityException e) {
                Log.w(TAG, "Bluetooth write failed: " + peer, e);
                closeQuietly();
            }
        }

        void closeQuietly() {
            closed = true;
            try { socket.close(); } catch (IOException | SecurityException ignored) { }
        }
    }

    private void dispatchIncoming(String peer, String line) {
        try {
            JSONObject payload = new JSONObject(line);
            JSONObject packet = new JSONObject();
            packet.put("peer", peer);
            packet.put("payload", payload);
            jsCall("onBluetoothMessage", packet.toString());
        } catch (JSONException e) {
            Log.w(TAG, "Ignoring invalid Bluetooth message", e);
        }
    }

    private void connectionClosed(String peer) {
        if (isHost) {
            try {
                JSONObject packet = new JSONObject();
                packet.put("peer", peer);
                packet.put("disconnected", true);
                jsCall("onBluetoothMessage", packet.toString());
            } catch (JSONException ignored) { }
        } else {
            status("disconnected", "A conexão Bluetooth foi encerrada.");
        }
    }

    private void disconnectAll() {
        shuttingDown = true;
        isHost = false;
        closeServerSocket();
        for (BtConnection c : connections.values()) c.closeQuietly();
        connections.clear();
    }

    private void closeServerSocket() {
        BluetoothServerSocket server = serverSocket;
        serverSocket = null;
        if (server != null) try { server.close(); } catch (IOException ignored) { }
    }

    private void status(String type, String detail) {
        jsCall("onBluetoothStatus", type, detail == null ? "" : detail);
    }

    private void jsCall(String method, String... args) {
        mainHandler.post(() -> {
            if (webView == null) return;
            StringBuilder js = new StringBuilder("if(window.").append(method).append(")window.").append(method).append('(');
            for (int i = 0; i < args.length; i++) {
                if (i > 0) js.append(',');
                js.append(JSONObject.quote(args[i]));
            }
            js.append(");");
            webView.evaluateJavascript(js.toString(), null);
        });
    }

    private String safeMessage(Exception e) {
        String value = e.getMessage();
        return value == null || value.trim().isEmpty() ? e.getClass().getSimpleName() : value;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else {
            jsCall("onBluetoothStatus", "backPressed", "");
            // Keep the game in-app; the in-game pause/leave controls remain available.
        }
    }

    @Override protected void onDestroy() {
        disconnectAll();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBT");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
