# Arena Jet 1.1 — notas da atualização

### Armas
- **Plasma:** munição limitada, cadência média e explosão de impacto.
- **Canhão elétrico:** projétil muito rápido, rastro azul e recuo discreto.
- **Lança-minas:** projétil com gravidade que pode aderir ao terreno; explode após um intervalo ou quando um adversário se aproxima.

### Equipamentos e movimento
- **Escudo:** recolher o equipamento dá até 55 pontos de escudo; o escudo reduz o dano recebido e é mostrado como um anel azul.
- **Cápsula de combustível:** restaura o combustível do jetpack.
- **Impulso rápido:** impulso horizontal com 2 segundos de recarga; celular usa ⚡, teclado usa Shift.

### HUD e desempenho
No menu principal, abra **Configurações** para alterar tamanho/estilo do HUD, opacidade dos controles, qualidade de efeitos, tremor, minimapa, feed, nomes e barras. As preferências ficam salvas localmente no aparelho.

### Cenários
- **Cavernas:** terreno mais escuro e túneis.
- **Ilhas partidas:** canais e plataformas separados.
- **Fortaleza:** blocos e plataformas de cobertura.
- Os mapas antigos Pequeno, Médio e Grande continuam disponíveis.

### Validação
O JavaScript passou na checagem de sintaxe do Node.js, e a estrutura HTML foi verificada quanto a IDs repetidos e referências literais a elementos ausentes. A compilação Android e o comportamento Bluetooth entre aparelhos ainda precisam ser executados/testados no ambiente do usuário.
