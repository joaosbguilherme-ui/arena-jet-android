# Arena Jet para Android — versão 1.1

Projeto Android Studio que incorpora o jogo em um WebView de tela cheia e usa Bluetooth clássico (RFCOMM) para partidas locais. O modo solo contra bots continua disponível. Este pacote contém código-fonte; ele não é um APK previamente compilado.

## Novidades da versão 1.1

- **Arsenal ampliado:** Plasma (explosão de energia), Canhão elétrico (projétil rápido) e Lança-minas (mina que pode aderir ao terreno e detonar por tempo/proximidade).
- **Equipamentos:** escudo de energia que absorve parte do dano e cápsula de combustível.
- **Movimento:** impulso rápido com recarga, acionado pelo botão ⚡ no celular ou Shift no teclado; aceleração aérea, frenagem no chão, colisões por subpassos e partículas de impacto ao aterrissar.
- **HUD personalizável:** escala, estilo compacto/clássico/à esquerda, opacidade dos controles, minimapa, feed de eliminações, barras de recursos e nomes dos jogadores.
- **Desempenho gráfico:** qualidade de efeitos Baixa/Equilibrada/Alta, intensidade de tremor ajustável e opção de clarões de explosão.
- **Mapas novos:** Cavernas, Ilhas partidas e Fortaleza, além dos mapas Pequeno, Médio e Grande. Cada cenário tem paleta e geometria próprias.
- **Efeitos visuais/sonoros:** projéteis de plasma e canhão elétrico diferenciados, brilho de escudo, rastros de impulso, clarões, partículas e sons próprios para armas novas.
- **Corrida de armas:** progressão estendida para 10 níveis/armas.

## Compilar

Requisitos: Android SDK Platform 35 e JDK 17. Na pasta do projeto, execute:

```bash
./gradlew --stop
./gradlew assembleDebug
```

O APK debug esperado fica em `app/build/outputs/apk/debug/app-debug.apk`.

Também há um workflow em `.github/workflows/build-apk.yml` para compilação no GitHub Actions quando a estrutura do projeto está na raiz do repositório (a pasta `.github/workflows` precisa estar diretamente na raiz do repositório).

## Bluetooth

Pareie os aparelhos nas configurações Bluetooth do Android antes de abrir o jogo. Um celular cria a sala e simula a partida; os demais se conectam ao anfitrião e enviam comandos. O anfitrião precisa manter o jogo aberto durante a partida. O modo local precisa de teste real em aparelhos: este pacote não afirma que o multiplayer foi validado em vários celulares.

## Arquivos

- `app/src/main/assets/arena-jet.html` — jogo atualizado e protocolo Bluetooth.
- `app/src/main/java/com/arenajet/game/MainActivity.java` — WebView, permissões e transporte Bluetooth.
- `app/src/main/AndroidManifest.xml` — permissões e Activity horizontal.
- `reference/arena-jet-original.html` — cópia original recebida.
- `reference/arena-jet-v1.1-bluetooth.html` — versão HTML atualizada para referência.
